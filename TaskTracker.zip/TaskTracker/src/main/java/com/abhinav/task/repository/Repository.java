package com.abhinav.task.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abhinav.task.dao.Tasks;

public interface Repository extends JpaRepository<Tasks, String>{

}
