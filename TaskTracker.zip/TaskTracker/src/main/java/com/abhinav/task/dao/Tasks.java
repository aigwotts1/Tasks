package com.abhinav.task.dao;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "tasks")
public class Tasks {
	
	@Id
    @Column(name = "id")
	@Min(value = 1)
	private String id;
	@NotNull(message = "Title Not Valid")
	private String title;
	@NotNull(message = "Description Not Valid")
	private String description;
    @Column(name = "due_date")
	@NotNull(message = "Invalid date format expected format : dd/mm/yyyy")
	private Date dueDate;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	@Override
	public String toString() {
		return "Tasks [id=" + id + ", title=" + title + ", description=" + description + ", dueDate=" + dueDate + "]";
	}
	
}