package com.abhinav.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.abhinav.task.dao.Tasks;
import com.abhinav.task.exception.TaskException;
import com.abhinav.task.repository.Repository;

@org.springframework.stereotype.Service
public class Service {

	@Autowired
	Repository repository;
	
	public Tasks createTask(Tasks task) {
		if(repository.findById(task.getId()).isPresent()) {
			throw new TaskException("Task with this id already Exists!!!");
		}
		return repository.save(task);
	}
	
	public Tasks updateTask(String id,Tasks task) {
		Tasks updatedTask = getTaskById(id);
		updatedTask.setTitle(task.getTitle());
		updatedTask.setDescription(task.getDescription());
		updatedTask.setDueDate(task.getDueDate());
		return repository.save(updatedTask);
	}
	
	public Tasks getTaskById(String id) {
		return repository.findById(id).orElseThrow(()-> new TaskException("Task with this id Not Found"));
	}
	
	public List<Tasks> getTasks(){
		return repository.findAll();
	}
	
	public void deleteTaskById(String id) {
		if(getTaskById(id) != null) {
			repository.deleteById(id);
		}
	}


}

