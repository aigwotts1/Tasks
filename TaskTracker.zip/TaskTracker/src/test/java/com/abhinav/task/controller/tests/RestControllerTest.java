package com.abhinav.task.controller.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.abhinav.task.controller.RestController;
import com.abhinav.task.dao.Tasks;
import com.abhinav.task.service.Service;

public class RestControllerTest {

    @Mock
    private Service service;

    @InjectMocks
    private RestController restController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateTask() {
        Tasks task = new Tasks();
        task.setId("1");
        task.setTitle("Test Task");
        task.setDescription("Test Description");
        task.setDueDate(new Date());

        when(service.createTask(any())).thenReturn(task);

        ResponseEntity<Tasks> response = restController.createTask(task);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(task, response.getBody());
    }

    @Test
    public void testUpdateTask() {
        Tasks task = new Tasks();
        task.setId("1");
        task.setTitle("Updated Task");
        task.setDescription("Updated Description");
        task.setDueDate(new Date());

        when(service.updateTask(eq("1"), any())).thenReturn(task);

        ResponseEntity<Tasks> response = restController.updateTask("1", task);

        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
        assertEquals(task, response.getBody());
    }

    @Test
    public void testGetTaskById() {
        Tasks task = new Tasks();
        task.setId("1");
        task.setTitle("Test Task");
        task.setDescription("Test Description");
        task.setDueDate(new Date());

        when(service.getTaskById("1")).thenReturn(task);

        ResponseEntity<Tasks> response = restController.getTaskById("1");

        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
        assertEquals(task, response.getBody());
    }

    @Test
    public void testGetTasks() {
        List<Tasks> tasks = new ArrayList<>();
        tasks.add(new Tasks());
        tasks.add(new Tasks());

        when(service.getTasks()).thenReturn(tasks);

        ResponseEntity<List<Tasks>> response = restController.getTasks();

        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
        assertEquals(tasks, response.getBody());
    }

    @Test
    public void testDeleteTaskById() {
        doNothing().when(service).deleteTaskById("1");

        ResponseEntity<Void> response = restController.deleteTaskById("1");

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }
}

