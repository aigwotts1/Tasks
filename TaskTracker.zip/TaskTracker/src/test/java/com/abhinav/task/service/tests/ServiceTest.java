package com.abhinav.task.service.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.abhinav.task.dao.Tasks;
import com.abhinav.task.exception.TaskException;
import com.abhinav.task.repository.Repository;
import com.abhinav.task.service.Service;

public class ServiceTest {

    @Mock
    private Repository repository;

    @InjectMocks
    private Service service;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateTask() {
        Tasks task = new Tasks();
        task.setId("1");
        task.setTitle("Test Task");
        task.setDescription("Test Description");
        task.setDueDate(new Date());

        when(repository.findById(any())).thenReturn(Optional.empty());
        when(repository.save(any())).thenReturn(task);

        Tasks result = service.createTask(task);
        assertEquals(task, result);

    }

    @Test
    public void testUpdateTask() {
        Tasks existingTask = new Tasks();
        existingTask.setId("1");
        existingTask.setTitle("Existing Task");
        existingTask.setDescription("Existing Description");
        existingTask.setDueDate(new Date());

        Tasks updatedTask = new Tasks();
        updatedTask.setTitle("Updated Task");
        updatedTask.setDescription("Updated Description");
        updatedTask.setDueDate(new Date());

        when(repository.findById(any())).thenReturn(Optional.of(existingTask));
        when(repository.save(any())).thenReturn(updatedTask);

        Tasks result = service.updateTask("1", updatedTask);
        assertNotEquals(existingTask, result);

    }

    @Test
    public void testGetTaskById() {
        Tasks task = new Tasks();
        task.setId("1");
        task.setTitle("Test Task");
        task.setDescription("Test Description");
        task.setDueDate(new Date());

        when(repository.findById(any())).thenReturn(Optional.of(task));

        Tasks result = service.getTaskById("1");
        assertEquals(task, result);


    }

    @Test
    public void testGetTasks() {
        List<Tasks> tasks = new ArrayList<>();
        tasks.add(new Tasks());
        tasks.add(new Tasks());

        when(repository.findAll()).thenReturn(tasks);

        List<Tasks> results = service.getTasks();
        assertEquals(tasks, results);


    }

    @Test
    public void testDeleteTaskById() {
        Tasks task = new Tasks();
        task.setId("1");
        task.setTitle("Test Task");
        task.setDescription("Test Description");
        task.setDueDate(new Date());

        when(repository.findById(any())).thenReturn(Optional.of(task));

        service.deleteTaskById("1");

        verify(repository).deleteById("1");
    }
    @Test
    public void testCreateTaskWithExistingId() {
        Tasks task = new Tasks();
        task.setId("1");

        when(repository.findById("1")).thenReturn(Optional.of(task));

        assertThrows(TaskException.class, () -> service.createTask(task));
    }

    @Test
    public void testGetNonExistentTaskById() {
        when(repository.findById("2")).thenReturn(Optional.empty());

        assertThrows(TaskException.class, () -> service.getTaskById("2"));
    }

    @Test
    public void testDeleteNonExistentTaskById() {
        when(repository.findById("3")).thenReturn(Optional.empty());

        assertThrows(TaskException.class, () -> service.deleteTaskById("3"));
    }
}
